package threeTest;
/**
 * 工人类
 * @author y
 *
 */
public class Worker extends Person{
private String jobNumber;//工号

public String getJobNumber() {
	return jobNumber;
}

public void setJobNumber(String jobNumber) {
	this.jobNumber = jobNumber;
}
/**
 * 工作方法
 */
public void work() {
	System.out.println("我爱工作");
}
/**
 * 吃的方法重写
 */
public void eat() {
	System.out.println(getName() + "正在吃饭");
}

/**
 * 睡觉的方法重写
 */
public void sleep() {
	System.out.println(getName() + "正在睡觉");
}
}
