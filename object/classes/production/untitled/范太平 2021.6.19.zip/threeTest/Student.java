package threeTest;

public class Student extends Person {
	private String no;

	public String getNo() {
		return no;
	}

	public void setNo(String no) {
		this.no = no;
	}

	/**
	 * 学习方法
	 */
	public void study() {
		System.out.println("我爱学习");
	}

	/**
	 * 吃的方法重写
	 */
	public void eat() {
		System.out.println(getName() + "正在吃饭");
	}

	/**
	 * 睡觉的方法重写
	 */
	public void sleep() {
		System.out.println(getName() + "正在睡觉");
	}
}
