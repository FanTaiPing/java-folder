package threeTest;
/**
 ** 编写一个Person抽象类，要求含有姓名（name）年龄（age）两个私有属性以及吃饭（eat） 和睡觉（sleep）两个抽象方法
 * 并写出带参构造方法，创建学生（student）和工人（worker） 两个类，继承Person类
 * 学生类多出了私有属性学号和学习方法（输出我爱学习）
 * 工 人类多出了私有属性工号和工作方法（输出我爱工作）
 * 在主函数中创建学生和工人类 的实例对象，使用构造方法赋值，并输出所有属性和方法
 * @author y
 *
 */
public class TestStuAndWorker {
public static void main(String[] args) {
	Student stu = new Student();
	stu.setNo("1001");
	stu.setName("李白");
	stu.setAge(1000);
	System.out.println("学号：" + stu.getNo() + "\t姓名：" + stu.getName() + "\t年龄：" + stu.getAge());
	stu.study();
	stu.eat();
	stu.sleep();
	
	Worker work = new Worker();
	work.setJobNumber("1002");
	work.setName("韩信");
	work.setAge(1001);
	System.out.println("工号：" + work.getJobNumber() + "\t姓名：" + work.getName() + "\t年龄：" + work.getAge());
	work.work();
	work.eat();
	work.sleep();
}
}
