package twoTest;

public class TestStudent {
	public static void main(String[] args) {
		Student stu = new Student();
		stu.setName("孙悟空 ");
		stu.setSex("女");
		stu.setAge(19);
		stu.setClasses("三年级二班");
		stu.ACode();
		System.out.println("姓名：" + stu.getName() + "性别：" + stu.getSex() + "年龄：" + stu.getAge() + "班级：" + stu.getClasses());

	}
}
