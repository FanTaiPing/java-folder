package twoTest;
/**
 * 学生
 * @author y
 *
 */
public class Student implements Programmer {
	private String name;
	private String sex;
	private int age;
	private String classes;

	public Student(String name, String sex, int age, String classes) {
		this.name = name;

		this.sex = sex;
		this.age = age;
		this.classes = classes;
	}

	public Student() {

	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getClasses() {
		return classes;
	}

	public void setClasses(String classes) {
		this.classes = classes;
	}

	@Override
	public void ACode() {
		System.out.println("程序员在敲代码!");

	}

}
