package twoTest;

/**
 * 程序员接口
 * 
 * @author y
 *
 */
public interface Programmer {
	void ACode();
}
