package oneTest;

/**
 * 利用继承，来描述，人，老师，学生之间的关系 老师含有属性：name，age，subject，含有方法：eat，teach，toString
 * 学生含有属性：name，age，class，含有方法：eat，study，toString
 * 利用继承的思想，从老师和学生中抽象出人，并创建Test进行调用并输出（System.out）
 * 
 * @author y
 *
 */
public class TestPerson {
	public static void main(String[] args) {
		//创建一个学生对象
		Student stu = new Student("刘备",1500,"三年级一班");
//		stu.name = "刘备";
//		stu.age = 1500;
//		stu.classes = "三年级一班";

		//调用属性和方法
		stu.study("java");
		stu.eat("香蕉");
		System.out.println(stu.toString());

		//创建一个老师对象
		Teacher tea = new Teacher("诸葛亮",1501,"JAVA");
//		tea.name = "诸葛亮";
//		tea.age = 1501;
//		tea.subject = "算命";

		//调用属性和方法
		tea.teach();
		tea.eat("苹果");
		System.out.println(tea.toString());
	}
}
