package oneTest;

/**
 * 老师类
 * 
 * @author y
 *
 */
public class Teacher extends Person {
	String subject;// 学科

	/**
	 * 子类带参构造方法
	 * 
	 * @param name
	 * @param age
	 * @param subject
	 */
	public Teacher(String name, int age, String subject) {
		super(name,age);
		this.subject = subject;
	}

	/**
	 * 子类无参构造方法
	 */
	public Teacher() {

	}

	/**
	 * 教授方法
	 */
	public void teach() {
		System.out.println("我教授的科目是：" + subject);
	}

	/**
	 * 重写toString()方法
	 */
	public String toString() {
		return "我的名字是：" + name + "，我的年龄是：" + age;
	}
}
