package oneTest;

/**
 * 人
 * 
 * @author y
 *
 */
public abstract class Person {
	String name;// 姓名
	int age;// 年龄

	/**
	 * 父类带参构造方法
	 * 
	 * @param name
	 * @param age
	 */
	public Person(String name, int age) {
		this.name = name;
		this.age = age;
	}

	/**
	 * 父类无参构造方法
	 */
	public Person() {

	}

	/**
	 * 吃的方法
	 * 
	 * @param something
	 */
	public void eat(String something) {
		System.out.println("我爱吃" + something);
	}

	/**
	 * toString()抽象方法
	 */
	public abstract String toString();
}
