package oneTest;

/**
 * 学生类
 * 
 * @author y
 *
 */
public class Student extends Person {
	String classes;// 班级

	/**
	 * 子类带参构造方法
	 * 
	 * @param name
	 * @param age
	 * @param classes
	 */
	public Student(String name, int age, String classes) {
		super(name,age);
		this.classes = classes;
	}

	/**
	 * 子类无参构造方法
	 */
	public Student() {

	}

	/**
	 * 学习方法
	 * 
	 * @param subject
	 */
	public void study(String subject) {
		System.out.println("我热爱学习" + subject);
	}

	/**
	 * 重写toString()方法
	 */
	public String toString() {
		return "我的名字是：" + name + "，我的年龄是：" + age + ",我的班级是：" + classes;
	}

}
