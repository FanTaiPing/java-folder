package com.km.sglototo.vo;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * <p>
 * 会员表
 * </p>
 *
 * 
 * @since 2019-04-19
 */
@Data
public class UmsMemberInfoDetail implements Serializable {
//
//    private UmsMember member;
//    private List<SmsCouponHistory> histories;
}
