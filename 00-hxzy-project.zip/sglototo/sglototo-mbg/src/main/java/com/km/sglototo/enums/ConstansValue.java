package com.km.sglototo.enums;

import com.google.common.collect.Lists;

import java.util.List;

/**
 * Created by Administrator on 2019/8/9.
 */
public class ConstansValue {
    public static final List<String> IGNORE_TENANT_TABLES = Lists.newArrayList("columns", "tables",
            "gen_config");



}
