package com.km.sglototo.enums;

public interface BaseEnum<K> {
    K code();

    String desc();
}
