package com.km.sglototo.vo;

import lombok.Getter;
import lombok.Setter;

/**
 * Created by Administrator on 2019/11/23.
 */
@Setter
@Getter
public class BlobUpload {

    String fileName;
    String fileUrl;
    String thumbnailUrl;
}
