package com.km.sglototo.vo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class IdStatus {
    private Long id;
    private Integer status;

}
