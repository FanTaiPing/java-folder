package com.km.sglototo.vo;

import lombok.Data;

/**
 * @Auther:
 * @Date: 2019/5/21 19:15
 * @Description:
 */
@Data
public class LogStatisc {
    private String method;
    private int count;
    private int avgMin;
    private int count1;
    private int count2;
    private int count3;
    private int count4;
    private int count5;
    private int count6;

    private int sum;
    private int sum1;
    private int sum2;
    private int sum3;
    private int sum4;
    private int sum5;
    private int sum6;
}
