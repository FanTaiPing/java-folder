package com.km.sglototo.sys.mapper;


import com.km.sglototo.sys.entity.SysOrg;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author xt
* @date 2021-02-25
*/
public interface SysOrgMapper extends BaseMapper<SysOrg> {
}
