package com.km.sglototo.sys.entity;

import lombok.Data;

/**
 * <p>
 * 后台用户表
 * </p>
 *
 * 
 * @since 2019-04-14
 */
@Data
public class SysUserVo extends SysUser {


}
