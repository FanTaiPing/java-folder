package com.fileServer;

public class ApiPath {
	   String FILEPATH;

	public String getFILEPATH() {
		return FILEPATH;
	}

	public void setFILEPATH(String fILEPATH) {
		FILEPATH = fILEPATH;
	}
	
}
