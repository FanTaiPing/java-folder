<template> 
  <admin-detail :is-edit='false'></admin-detail>
</template>
<script>
  import AdminDetail from './components/Detail'
  export default {
    name: 'addVersion',
    components: { AdminDetail }
  }
</script>
<style>
</style>


