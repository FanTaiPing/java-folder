<template> 
  <role-detail :is-edit='true'></role-detail>
</template>
<script>
  import RoleDetail from './components/RoleDetail'
  export default {
    name: 'updateRole',
    components: { RoleDetail }
  }
</script>
<style>
</style>


