<template> 
    <sysOrg-detail :is-edit='false'>
</sysOrg-detail>
</template>
<script>
    import SysOrgDetail from './components/detail'

    export default {
        name: 'addSysOrg',
        components: {SysOrgDetail}
    }
</script>
<style>
</style>


