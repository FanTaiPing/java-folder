<template> 
    <sysOrg-detail :is-edit='true'>
</sysOrg-detail>
</template>
<script>
    import SysOrgDetail from './components/detail'

    export default {
        name: 'updateSysOrg',
        components: {SysOrgDetail}
    }
</script>
<style>
</style>


