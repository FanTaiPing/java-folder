<template>
  <div class="home">
    我是杨家馨1
  </div>
</template>

<script type="text/ecmascript-6">

</script>
<style lang="stylus" rel="stylesheet/stylus">
</style>