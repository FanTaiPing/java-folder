package me.zhengjie.modules.train.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import me.zhengjie.modules.train.entity.Interview;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 *
 * @since 2019-04-14
 */
public interface InterviewMapper extends BaseMapper<Interview> {

}
