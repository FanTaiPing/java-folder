package com.baizhi.dao;

import com.baizhi.entity.Info;

public interface InfoDAO {
    //保存身份信息方法
    int save(Info info);
}
